package com.example.carrace;

import org.junit.Test;

import static org.junit.Assert.*;
/**
 * shimon Desta 203670286
 * HW01 - Car Game
 **/
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }
}